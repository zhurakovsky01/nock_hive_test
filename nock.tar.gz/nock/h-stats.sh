#!/usr/bin/env bash

####################################################################################
##
## Адаптований NOCK Prover stats для вашої конфігурації
## Не потребує завантаження h-manifest.conf
##
####################################################################################

# ============================================================================
# НАЛАШТУВАННЯ - адаптовано під ваш h-manifest.conf
# ============================================================================

CUSTOM_NAME="nock"
CUSTOM_LOG_BASENAME="/var/log/miner/custom/nock.log"
CUSTOM_VERSION="0.1.5+1"  # Змініть якщо у вас інша версія
CUSTOM_CONFIG_FILENAME="/hive/miners/custom/nock/miner.conf"

# ============================================================================
# Основний код (не змінюйте)
# ============================================================================

# Видаляємо .log якщо він вже є в CUSTOM_LOG_BASENAME
LOG_FILE="${CUSTOM_LOG_BASENAME%.log}.log"

accepted_shares=$(grep -c "Heartbeat success" "$LOG_FILE" 2>/dev/null || echo 0)
rejected_shares=0

# Отримуємо останній запис про швидкість GPU
stats_raw=$(cat "$LOG_FILE" 2>/dev/null | grep "INFO Card-0 speed" | tail -n 1)
echo "stats_raw: $stats_raw"

# Перевірка свіжості логу
maxDelay=120
time_now=$(date -u +%s)
echo "time_now : $time_now"

# Перевіряємо чи є валідні дані
if [[ -n "$stats_raw" ]]; then
    total_hashrate_str=$(echo "$stats_raw" | grep -o '[0-9.]* p/s' | cut -d' ' -f1)
    total_hashrate=$(echo "$total_hashrate_str * 1000" | bc | cut -d'.' -f1)
    diffTime=0
else
    diffTime=999
fi

echo "diffTime : $diffTime"

if [ "$diffTime" -lt "$maxDelay" ]; then
        echo "total_hashrate : $total_hashrate"

        gpu_stats=$(< "$GPU_STATS_JSON")
        
        echo "GPU_STATS_JSON=$GPU_STATS_JSON" >&2
        ls -l "$GPU_STATS_JSON" >&2
        jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" >&2

        readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" 2>/dev/null)
        busids=(${gpu_stats[0]})
        brands=(${gpu_stats[1]})
        temps=(${gpu_stats[2]})
        fans=(${gpu_stats[3]})
        gpu_count=${#busids[@]}

        hash_arr=()
        busid_arr=()
        fan_arr=()
        temp_arr=()

        if [ $(gpu-detect NVIDIA) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect NVIDIA)
                BRAND_MINER="nvidia"
        elif [ $(gpu-detect AMD) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect AMD)
                BRAND_MINER="amd"
        fi
        
        total_hashrate_sum=0
        [[ ${brands[0]} == 'cpu' ]] && internalCpuShift=1 || internalCpuShift=0
        
        for(( i=0; i < gpu_count; i++ )); do
                if [[ "${brands[i]}" == 'cpu' ]]; then
                    continue
                fi
                
                [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
                busid_arr+=($((16#${BASH_REMATCH[1]})))
                temp_arr+=(${temps[i]})
                fan_arr+=(${fans[i]})                
                
                gpu_index_for_log=$i
                if [[ $internalCpuShift -eq 1 ]]; then
                    gpu_index_for_log=$((i - internalCpuShift))
                fi
                
                gpu_raw=$(grep "Card-$gpu_index_for_log" "$LOG_FILE" | grep "p/s" | tail -n 1 | tr -d '\000')
                
                echo "gpu_raw : $gpu_raw"  
                
                hashrate=0
                if [[ -n "$gpu_raw" ]]; then
                    hashrate_str=$(echo "$gpu_raw" | grep -o '[0-9.]* p/s' | cut -d' ' -f1)
                    if [[ -n "$hashrate_str" ]]; then
                        hashrate=$(echo "$hashrate_str * 1000000" | bc | cut -d'.' -f1)
                    fi
                fi

                echo "hashrate: $hashrate"
                hashrate_khs=$(echo "scale=2; $hashrate" | bc)
                hash_arr+=($hashrate_khs)
                total_hashrate_sum=$((total_hashrate_sum + hashrate))
                echo "GPU $gpu_index_for_log hash: $hashrate_khs H/s"
        done

        hash_json=$(printf '%s\n' "${hash_arr[@]}" | jq -cs '.')
        bus_numbers=$(printf '%s\n' "${busid_arr[@]}"  | jq -cs '.')
        fan_json=$(printf '%s\n' "${fan_arr[@]}"  | jq -cs '.')
        temp_json=$(printf '%s\n' "${temp_arr[@]}"  | jq -cs '.')

        uptime=$(( $(date +%s) - $(stat -c %Y "$CUSTOM_CONFIG_FILENAME" 2>/dev/null || date +%s) ))

        stats=$(jq -nc \
            --argjson hs "$hash_json" \
            --arg ver "$CUSTOM_VERSION" \
            --arg ths "$total_hashrate" \
            --argjson bus_numbers "$bus_numbers" \
            --argjson fan "$fan_json" \
            --argjson temp "$temp_json" \
            --arg uptime "$uptime" \
            --argjson accepted "$accepted_shares" \
            --argjson rejected "$rejected_shares" \
            '{ hs: $hs, hs_units: "hs", algo : "NOCK", ver:$ver , uptime: $uptime, ar: [$accepted,$rejected], bus_numbers: $bus_numbers, temp: $temp, fan: $fan }')
        
        khs=$(echo "scale=2; $total_hashrate_sum/1000" | bc)
else
  khs=0
  stats="null"
fi

echo "=========================================="
echo "Log file        : $LOG_FILE"
echo "Config file     : $CUSTOM_CONFIG_FILENAME"
echo "Time diff       : $diffTime sec"
echo "Accepted shares : $accepted_shares"
echo "Total KHS       : $khs"
echo "Stats output    : $stats"
echo "=========================================="

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
